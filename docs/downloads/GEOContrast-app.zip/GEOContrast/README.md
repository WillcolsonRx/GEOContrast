# GEOContrast

Open GEOContrast.Rproj in RStudio. From this folder run:

```r
source("install_packages.R")
shiny::runApp()
```

Optional: source("install_annotation_dbs.R"). Internet is needed for installation and GEO downloads. One organism per analysis. RNA-seq requires integer raw counts, not TPM/FPKM/CPM. This download preserves the uploaded v0.4.8 analysis source; R runtime validation is still required. See the included field guide.
